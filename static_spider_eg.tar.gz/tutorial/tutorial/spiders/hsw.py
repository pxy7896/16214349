# -*- coding: utf-8 -*-
import scrapy
from tutorial.items import TutorialItem

class hsw(scrapy.Spider):
	name = 'hsw'
	allowed_domains = ['hsw.cn']
	start_urls = ['http://finance.hsw.cn/hyxw/index.shtml']

	def parse(self, response):
        	list_urls = response.xpath('//div[@class="listleft"]/ul/li/h3/a/@href').extract()
		for url in list_urls:
			yield scrapy.Request(url, callback=self.parse_item)

	def parse_item(self, response):
		item = TutorialItem()
		item['title'] = response.xpath('//div[@class="hd"]/h1/text()').extract_first()
		item['get_time'] = response.xpath('//span[@class="article-time"]/text()').extract_first()
		yield item
		

'''
scrapy crawl hsw -o hsw.csv

output format: .json, jsonl, csv, xml

'''